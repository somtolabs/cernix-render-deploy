// ============================================================
// Render + flow controller
// ============================================================

function goto(screen){
  if(screen==='landing'){
    STATE.formStudent=null;
    STATE.formError='';
    STATE.scanState='idle';
  }
  if(screen==='scanner'){
    STATE.scanState='idle';
  }
  setState({flowScreen:screen});
}

function submitRegister(e){
  e.preventDefault();
  const m = STATE.formMatric.trim();
  const r = STATE.formRRR.trim();
  if(!m){ STATE.formError='Matriculation number is required.'; return render(); }
  if(!r || r.length<10){ STATE.formError='Remita RRR must be 10-12 digits.'; return render(); }
  const found = STUDENTS.find(s=>s.matric.toLowerCase()===m.toLowerCase());
  if(!found){
    STATE.formError='Matric number not found in the Student Information System.';
    return render();
  }
  STATE.formLoading=true; STATE.formError=''; render();
  setTimeout(()=>{
    STATE.formLoading=false;
    STATE.formStudent=found;
    goto('success');
  }, 1400);
}

function submitLogin(e){
  e.preventDefault();
  const u = STATE.loginUser.trim();
  const p = STATE.loginPass;
  if(!u || !p){ STATE.loginError='Both username and password are required.'; return render(); }
  const ex = EXAMINERS.find(x=>x.username===u);
  if(!ex){ STATE.loginError='Invalid credentials.'; return render(); }
  STATE.loginLoading=true; STATE.loginError=''; render();
  setTimeout(()=>{
    STATE.loginLoading=false;
    goto('scanner');
  }, 1100);
}

function simulateScan(decision){
  STATE.scanState='scanning';
  render();
  setTimeout(()=>{
    const idx = Math.floor(Math.random()*STUDENTS.length);
    const s = STUDENTS[idx];
    const now = new Date();
    const t = now.toTimeString().slice(0,8);
    const token = "a7f2"+Math.random().toString(16).slice(2,10);
    STATE.lastScanStudent = {
      name:s.name, matric:s.matric, dept:s.dept, initials:s.initials,
      decision, time:t, token:token.slice(0,4)+'…'+token.slice(-4)
    };
    STATE.scanCounts = {
      total: STATE.scanCounts.total+1,
      approved: STATE.scanCounts.approved + (decision==='APPROVED'?1:0),
      rejected: STATE.scanCounts.rejected + (decision==='REJECTED'?1:0),
      duplicate: STATE.scanCounts.duplicate + (decision==='DUPLICATE'?1:0),
    };
    STATE.scanState = decision.toLowerCase();
    render();
  }, 700);
}

function resetScan(){
  STATE.scanState='idle';
  render();
}

// ============================================================
// Flow prototype (single phone, clickable)
// ============================================================
function renderFlow(){
  const s = STATE.flowScreen;
  const dark = document.body.classList.contains('dark-prototype');
  let html = '';
  if(s==='landing') html = screenLanding(dark);
  else if(s==='register') html = screenRegister(dark);
  else if(s==='success') html = screenSuccess(dark);
  else if(s==='login') html = screenLogin(dark);
  else if(s==='scanner') html = screenScanner(dark);
  else if(s==='admin') html = screenAdminMobile(dark);
  else html = screenLanding(dark);

  return `
    <div style="padding:40px 16px 80px;display:flex;flex-direction:column;align-items:center;gap:24px">
      <div style="display:flex;gap:8px;flex-wrap:wrap;justify-content:center;max-width:640px">
        ${['landing','register','success','login','scanner','admin'].map(sc=>`
          <button onclick="goto('${sc}')" style="padding:8px 14px;border-radius:999px;font-size:12px;font-weight:500;
            background:${sc===s?'var(--navy)':'var(--bg-2)'};color:${sc===s?'#fff':'var(--ink-2)'};
            border:1px solid ${sc===s?'var(--navy)':'var(--line)'}">
            ${sc==='landing'?'Landing':sc==='register'?'Register':sc==='success'?'QR Success':sc==='login'?'Examiner Login':sc==='scanner'?'Scanner':'Admin'}
          </button>
        `).join('')}
        <button onclick="document.body.classList.toggle('dark-prototype'); document.documentElement.classList.toggle('dark'); render()" style="padding:8px 14px;border-radius:999px;font-size:12px;font-weight:500;background:var(--bg-2);color:var(--ink-2);border:1px solid var(--line)">
          ${dark?'☀︎ Light':'☾ Dark'}
        </button>
      </div>
      <div class="frame-wrap ${dark?'dark':''}">
        <div class="phone">${html}</div>
      </div>
      <p style="font-size:12px;color:var(--ink-3);text-align:center;max-width:420px;line-height:1.5">
        Full clickable prototype. <b>Student flow:</b> Landing → Register (try matric <span class="mono">CSC/2021/001</span> + any 12-digit RRR) → QR success. <b>Examiner flow:</b> Landing → Login (try <span class="mono">examiner1</span> / <span class="mono">password123</span>) → Scanner → tap demo buttons for the three status takeovers.
      </p>
    </div>
  `;
}

// ============================================================
// Gallery of all screens, light + dark
// ============================================================
function renderGallery(modeFilter){
  const screens = [
    {key:'landing', label:'01 · Landing', build:(d)=>screenLanding(d)},
    {key:'register', label:'02 · Student Registration', build:(d)=>{
      const clone = {...STATE}; STATE.formMatric='CSC/2021/001'; STATE.formRRR='280007021192'; const h=screenRegister(d);
      Object.assign(STATE,clone); return h;
    }},
    {key:'register-err', label:'02b · Register · Error', build:(d)=>{
      const clone = {...STATE}; STATE.formMatric='XYZ/2021/999'; STATE.formRRR='123'; STATE.formError='Matric number not found in the Student Information System.'; const h=screenRegister(d);
      Object.assign(STATE,clone); return h;
    }},
    {key:'register-loading', label:'02c · Register · Loading', build:(d)=>{
      const clone = {...STATE}; STATE.formMatric='CSC/2021/001'; STATE.formRRR='280007021192'; STATE.formLoading=true; STATE.formError=''; const h=screenRegister(d);
      Object.assign(STATE,clone); return h;
    }},
    {key:'success', label:'03 · Registration Success (QR)', build:(d)=>{
      const clone={...STATE}; STATE.formStudent=STUDENTS[0]; const h=screenSuccess(d);
      Object.assign(STATE,clone); return h;
    }},
    {key:'login', label:'04 · Examiner Login', build:(d)=>screenLogin(d)},
    {key:'scanner-idle', label:'05 · Scanner · Idle', build:(d)=>{
      const clone={...STATE}; STATE.scanState='scanning'; STATE.lastScanStudent=null; const h=screenScanner(d); Object.assign(STATE,clone); return h;
    }},
    {key:'scanner-approved', label:'05a · VERIFIED (takeover)', build:(d)=>{
      const clone={...STATE};
      STATE.scanState='approved';
      STATE.lastScanStudent={name:'Adebayo Oluwaseun Emmanuel',matric:'CSC/2021/001',dept:'Computer Science',initials:'AO',decision:'APPROVED',time:'09:14:44',token:'a7f2…6b91'};
      STATE.scanCounts={total:13,approved:10,rejected:2,duplicate:1};
      const h=screenScanner(d);
      Object.assign(STATE,clone); return h;
    }},
    {key:'scanner-rejected', label:'05b · REJECTED (takeover)', build:(d)=>{
      const clone={...STATE};
      STATE.scanState='rejected';
      STATE.lastScanStudent={name:'Unknown',matric:'???',dept:'—',initials:'??',decision:'REJECTED',time:'09:40:18',token:'ffe2…3a22'};
      STATE.scanCounts={total:13,approved:9,rejected:3,duplicate:1};
      const h=screenScanner(d);
      Object.assign(STATE,clone); return h;
    }},
    {key:'scanner-duplicate', label:'05c · ALREADY USED (takeover)', build:(d)=>{
      const clone={...STATE};
      STATE.scanState='duplicate';
      STATE.lastScanStudent={name:'Adebayo Oluwaseun Emmanuel',matric:'CSC/2021/001',dept:'Computer Science',initials:'AO',decision:'DUPLICATE',time:'09:31:12',token:'a7f2…6b91'};
      STATE.scanCounts={total:13,approved:9,rejected:2,duplicate:2};
      const h=screenScanner(d);
      Object.assign(STATE,clone); return h;
    }},
    {key:'admin-mobile', label:'06 · Admin · Mobile', build:(d)=>screenAdminMobile(d)},
  ];

  const variants = [];
  if(modeFilter==='both'||modeFilter==='light') variants.push({mode:'Light',dark:false});
  if(modeFilter==='both'||modeFilter==='dark') variants.push({mode:'Dark',dark:true});

  let out = `<div class="gallery">`;
  for(const s of screens){
    for(const v of variants){
      out += `
        <div class="frame-wrap ${v.dark?'dark':''}">
          <div class="frame-label"><span class="dot"></span>${s.label} · ${v.mode}</div>
          <div class="phone">${s.build(v.dark)}</div>
        </div>
      `;
    }
  }
  // Admin desktop variants
  for(const v of variants){
    out += `
      <div class="frame-wrap ${v.dark?'dark':''}" style="grid-column:1/-1">
        <div class="frame-label"><span class="dot"></span>06b · Admin Dashboard · Desktop · ${v.mode}</div>
        <div class="desktop">
          <div class="chrome">
            <div class="traffic"><i></i><i></i><i></i></div>
            <div class="urlbar">🔒 cernix.unilag.edu.ng/admin/dashboard</div>
          </div>
          <div class="canvas">${screenAdminDesktop(v.dark)}</div>
        </div>
      </div>
    `;
  }
  out += `</div>`;
  return out;
}

// ============================================================
// Component library
// ============================================================
function renderLibrary(){
  return `
  <div class="components-page">
    <div style="max-width:1200px;margin-bottom:40px">
      <div class="logo-mark" style="margin-bottom:12px"><span class="logo-glyph"></span><span>CERNIX</span></div>
      <h1 style="font-size:36px;font-weight:800;letter-spacing:-.03em;margin:0 0 8px">Design System</h1>
      <p style="font-size:15px;color:var(--ink-3);max-width:640px;line-height:1.6">Institutional but modern. Cryptographic exam-hall UI, engineered for bright-light legibility and zero ambiguity in decisions.</p>
    </div>

    <section class="comp-section">
      <h2>Foundations</h2>
      <h3>Color</h3>
      <div class="comp-grid">
        <div class="comp-demo">
          <div class="demo-label">Brand</div>
          <div class="swatch">
            <i style="background:#0f2050" title="Navy #0f2050"></i>
            <i style="background:#1a3370"></i>
            <i style="background:#091638"></i>
            <i style="background:#2d6cff" title="Electric blue"></i>
            <i style="background:#5b8dff"></i>
          </div>
          <div style="font-size:11px;color:var(--ink-3);margin-top:10px">Navy primary · Electric-blue accent</div>
        </div>
        <div class="comp-demo">
          <div class="demo-label">Status</div>
          <div class="swatch">
            <i style="background:#059669" title="Emerald — APPROVED"></i>
            <i style="background:#dc2626" title="Red — REJECTED"></i>
            <i style="background:#b45309" title="Amber — DUPLICATE"></i>
          </div>
          <div style="font-size:11px;color:var(--ink-3);margin-top:10px">APPROVED · REJECTED · ALREADY USED</div>
        </div>
        <div class="comp-demo">
          <div class="demo-label">Surfaces</div>
          <div class="swatch">
            <i style="background:#f4f4ef"></i>
            <i style="background:#ffffff"></i>
            <i style="background:#e6e4dc"></i>
            <i style="background:#0a0f1f"></i>
            <i style="background:#070a15"></i>
            <i style="background:#1a2142"></i>
          </div>
        </div>
      </div>
    </section>

    <section class="comp-section">
      <h3>Typography</h3>
      <div class="comp-grid">
        <div class="comp-demo">
          <div class="demo-label">Inter · Display</div>
          <div class="type-sample" style="font-size:36px;font-weight:800;letter-spacing:-.03em;line-height:1">Cryptographic<br/>Exam Access.</div>
          <div style="font-size:11px;color:var(--ink-3)">800 · -0.03em · 1</div>
        </div>
        <div class="comp-demo">
          <div class="demo-label">Inter · Body</div>
          <p style="font-size:14px;line-height:1.5;margin:0">End-to-end secure exam hall access control. AES-256-GCM encrypted QR tokens, HMAC-verified identities.</p>
          <div style="font-size:11px;color:var(--ink-3);margin-top:10px">400/500 · 1.5 leading</div>
        </div>
        <div class="comp-demo">
          <div class="demo-label">JetBrains Mono</div>
          <div class="mono" style="font-size:14px;line-height:1.6">CSC/2021/001<br/>280007021192<br/>a7f21ab9c8d4e5f6</div>
          <div style="font-size:11px;color:var(--ink-3);margin-top:10px">Matric · RRR · Token IDs</div>
        </div>
      </div>
    </section>

    <section class="comp-section">
      <h3>Buttons</h3>
      <div class="comp-grid">
        <div class="comp-demo">
          <div class="demo-label">Primary · Default</div>
          <button class="btn btn-primary">${ICO.shield} Generate QR</button>
        </div>
        <div class="comp-demo">
          <div class="demo-label">Primary · Loading</div>
          <button class="btn btn-primary" disabled>
            <span class="spin" style="width:18px;height:18px;border:2px solid rgba(255,255,255,.3);border-top-color:#fff;border-radius:50%;display:inline-block"></span>
            Verifying<span class="dots"><span></span><span></span><span></span></span>
          </button>
        </div>
        <div class="comp-demo">
          <div class="demo-label">Ghost</div>
          <button class="btn btn-ghost">${ICO.refresh.replace('class="i"','class="i i-sm"')} Refresh</button>
        </div>
      </div>
    </section>

    <section class="comp-section">
      <h3>Fields</h3>
      <div class="comp-grid">
        <div class="comp-demo">
          <div class="field mono" style="margin:0"><label>Matric No.</label><input class="input" placeholder="CSC/2021/001"/></div>
        </div>
        <div class="comp-demo">
          <div class="field err" style="margin:0"><label>RRR</label><input class="input" value="123"/><div class="err-msg">RRR must be 12 digits.</div></div>
        </div>
        <div class="comp-demo">
          <div class="field" style="margin:0"><label>Username</label><input class="input" placeholder="examiner1"/><div class="hint">Assigned by Admin</div></div>
        </div>
      </div>
    </section>

    <section class="comp-section">
      <h3>Status chips</h3>
      <div class="comp-grid">
        <div class="comp-demo" style="display:flex;gap:8px;flex-wrap:wrap">
          <span class="chip emerald">${ICO.check.replace('class="i"','class="i i-sm"')} APPROVED</span>
          <span class="chip red">${ICO.x.replace('class="i"','class="i i-sm"')} REJECTED</span>
          <span class="chip amber">${ICO.warn.replace('class="i"','class="i i-sm"')} DUPLICATE</span>
          <span class="chip navy">SESSION ACTIVE</span>
          <span class="chip blue">EXAMINER</span>
        </div>
      </div>
    </section>

    <section class="comp-section">
      <h3>Status takeovers (the defining pattern)</h3>
      <p style="font-size:13px;color:var(--ink-3);max-width:620px;margin:0 0 20px">Full-viewport color flash, 140px glyph, 56px headline. Designed for bright-sunlight exam-hall use with zero ambiguity.</p>
      <div style="display:flex;gap:20px;flex-wrap:wrap">
        <div class="phone" style="transform:scale(.85);transform-origin:top left;margin-bottom:-80px">
          ${screenScanner(false).replace('class="scanner"', 'class="scanner" style="visibility:hidden"')}
          <div class="takeover approved" style="animation:none">
            <div class="top"><span class="status-label">DECISION · APPROVED</span><span class="time">09:14:44</span></div>
            <div><div class="center" style="margin-top:20px"><div class="big-icon">${ICO.check}</div><h1 class="headline">VERIFIED</h1><p class="sub">Access granted.</p></div></div>
            <div class="bottom"><button>Next</button><button class="primary">Admit</button></div>
          </div>
        </div>
        <div class="phone" style="transform:scale(.85);transform-origin:top left;margin-bottom:-80px">
          <div class="takeover rejected" style="animation:none">
            <div class="top"><span class="status-label">DECISION · REJECTED</span><span class="time">09:40:18</span></div>
            <div><div class="center" style="margin-top:20px"><div class="big-icon">${ICO.x}</div><h1 class="headline">REJECTED</h1><p class="sub">Do not admit.</p></div></div>
            <div class="bottom"><button>Dismiss</button><button class="primary">Alert</button></div>
          </div>
        </div>
        <div class="phone" style="transform:scale(.85);transform-origin:top left;margin-bottom:-80px">
          <div class="takeover duplicate" style="animation:none">
            <div class="top"><span class="status-label">ALREADY USED</span><span class="time">09:31:12</span></div>
            <div><div class="center" style="margin-top:20px"><div class="big-icon">${ICO.warn}</div><h1 class="headline">ALREADY<br/>USED</h1><p class="sub">Entry denied.</p></div></div>
            <div class="bottom"><button>Dismiss</button><button class="primary">Audit</button></div>
          </div>
        </div>
      </div>
    </section>

    <section class="comp-section">
      <h3>QR token · Logo · Spinner</h3>
      <div class="comp-grid">
        <div class="comp-demo" style="text-align:center">
          <div style="width:180px;height:180px;padding:12px;background:#fff;border-radius:10px;margin:0 auto">${fakeQrSvg(42)}</div>
          <div style="font-size:11px;color:var(--ink-3);margin-top:10px;letter-spacing:.1em">AES-256-GCM · HMAC-SHA256</div>
        </div>
        <div class="comp-demo" style="display:flex;align-items:center;justify-content:center">
          <div class="logo-mark" style="font-size:20px"><span class="logo-glyph" style="width:44px;height:44px;border-radius:12px"></span><span style="letter-spacing:.22em">CERNIX</span></div>
        </div>
        <div class="comp-demo" style="display:flex;align-items:center;justify-content:center;gap:16px">
          <span class="spin" style="width:28px;height:28px;border:3px solid var(--line);border-top-color:var(--navy);border-radius:50%;display:inline-block"></span>
          <span class="dots" style="color:var(--navy);font-size:20px"><span></span><span></span><span></span></span>
        </div>
      </div>
    </section>
  </div>
  `;
}

// ============================================================
// Master render
// ============================================================
function render(){
  const root = document.getElementById('root');
  const mode = STATE.mode;

  // toggle dark class on root for library/flow modes
  document.documentElement.classList.remove('dark');

  if(mode==='lib'){
    root.innerHTML = renderLibrary();
    return;
  }
  if(mode==='flow'){
    root.innerHTML = renderFlow();
    return;
  }
  // both, light, dark — gallery
  root.innerHTML = renderGallery(mode);
}
