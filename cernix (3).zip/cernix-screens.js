// ============================================================
// Screen builders — return HTML strings
// ============================================================

function screenLanding(dark){
  return `
  <div class="screen landing ${dark?'dark':''}">
    <div class="notch"></div>
    <div class="status-bar"><span>9:41</span><span class="right">
      <svg class="i i-sm" viewBox="0 0 24 24" fill="currentColor" stroke="none"><path d="M2 22h4v-4H2zM8 22h4V14H8zM14 22h4V10h-4zM20 22h4V6h-4z"/></svg>
      <svg class="i i-sm" viewBox="0 0 24 24" fill="currentColor" stroke="none"><path d="M1 9l11 11L23 9c-6-6-16-6-22 0z"/></svg>
      <span style="font-size:11px">100%</span>
    </span></div>

    <div class="hero">
      <div class="grid-bg"></div>
      <div class="glow"></div>
      <div class="logo-mark" style="position:relative">
        <span class="logo-glyph"></span><span>CERNIX</span>
      </div>
      <h1 class="brand" style="position:relative"><span class="n">Cryptographic</span><br/>Exam Access.</h1>
      <p class="tag" style="position:relative">End-to-end secure exam hall access control. AES-256-GCM encrypted QR tokens, HMAC-verified identities, one-time admission.</p>

      <div class="stat-strip" style="position:relative">
        <div><b>AES-256</b><span>Encryption</span></div>
        <div><b>HMAC</b><span>Signed</span></div>
        <div><b>One-time</b><span>Tokens</span></div>
      </div>
    </div>

    <div class="portals">
      <button class="portal" onclick="goto('register')">
        <span class="accent-line"></span>
        <div class="ico student">${ICO.student}</div>
        <div class="txt">
          <h3>Student Portal</h3>
          <p>Register for your exam and get your one-time QR token</p>
        </div>
        <div class="arrow">${ICO.arrow}</div>
      </button>
      <button class="portal" onclick="goto('login')">
        <span class="accent-line"></span>
        <div class="ico examiner">${ICO.scan}</div>
        <div class="txt">
          <h3>Examiner Login</h3>
          <p>Scan student QR codes at the exam hall entrance</p>
        </div>
        <div class="arrow">${ICO.arrow}</div>
      </button>
    </div>

    <div class="system">
      <span class="pulse-dot"></span>
      <div style="flex:1"><b style="font-size:12px;font-weight:600;color:var(--emerald)">System operational</b><div style="font-size:11px;color:var(--ink-3)">Active session — ${SESSION.semester} ${SESSION.year}</div></div>
      <span class="chip emerald">LIVE</span>
    </div>

    <div class="footer-meta">CERNIX v1.0 · Session #${SESSION.id} · Secured by cryptographic primitives</div>
    <div class="home"></div>
  </div>`;
}

function screenRegister(dark){
  const s = STATE;
  return `
  <div class="screen register ${dark?'dark':''}">
    <div class="notch"></div>
    <div class="status-bar"><span>9:41</span><span class="right"><span style="font-size:11px">100%</span></span></div>

    <div class="topbar">
      <button class="back" onclick="goto('landing')">${ICO.back}</button>
      <h1>Exam Registration</h1>
    </div>

    <div class="progress-dots"><i class="on"></i><i></i></div>

    <div class="pad-lg">
      <div style="margin-bottom:18px">
        <h2 style="font-size:22px;font-weight:700;letter-spacing:-.02em;margin:0">Let's verify your payment</h2>
        <p style="font-size:14px;color:var(--ink-3);margin:6px 0 0;line-height:1.5">Enter your matriculation number and the Remita RRR from your fee payment to generate your exam QR.</p>
      </div>

      <div class="session-pill">
        <div class="left">
          <span>Active Session</span>
          <b>${SESSION.semester} · ${SESSION.year}</b>
        </div>
        <div class="fee">₦${SESSION.fee.toLocaleString()}</div>
      </div>

      <form id="regForm" onsubmit="submitRegister(event)" style="margin-top:22px">
        <div class="field mono ${s.formError && !s.formMatric?'err':''}">
          <label for="matric">Matriculation Number</label>
          <input class="input" id="matric" type="text" placeholder="CSC/2021/001" value="${s.formMatric}" oninput="STATE.formMatric=this.value" autocomplete="off" />
          <div class="hint">${ICO.chip.replace('class="i"','class="i i-sm"')} Format: Department / Year / Number</div>
        </div>
        <div class="field mono">
          <label for="rrr">Remita RRR Number</label>
          <input class="input" id="rrr" type="text" placeholder="280007021192" value="${s.formRRR}" oninput="STATE.formRRR=this.value" maxlength="12" autocomplete="off"/>
          <div class="hint">12-digit Retrieval Reference from your Remita payment receipt</div>
        </div>

        ${s.formError ? `<div class="error-box">${ICO.warn.replace('class="i"','class="i i-sm"')}<div><b>Registration failed.</b><br/>${s.formError}</div></div>` : ''}

        <button type="submit" class="btn btn-primary btn-block" style="margin-top:22px" ${s.formLoading?'disabled':''}>
          ${s.formLoading
            ? `<span class="spin" style="width:18px;height:18px;border:2px solid rgba(255,255,255,.3);border-top-color:#fff;border-radius:50%;display:inline-block"></span> Verifying payment<span class="dots"><span></span><span></span><span></span></span>`
            : `${ICO.shield} Generate my Exam QR`}
        </button>
      </form>

      <div style="display:flex;gap:10px;align-items:center;margin-top:20px;padding:12px;background:var(--bg);border-radius:12px;border:1px dashed var(--line-2)">
        ${ICO.lock.replace('class="i"','class="i i-sm"')}
        <div style="font-size:11px;color:var(--ink-3);line-height:1.45">Your QR token is encrypted with <b>AES-256-GCM</b> and signed with a per-session HMAC secret. It can only be redeemed once.</div>
      </div>

      <div style="text-align:center;font-size:11px;color:var(--ink-4);margin-top:20px">Need help? Visit the Bursary office · Block B</div>
    </div>

    <div class="home"></div>
  </div>`;
}

function screenSuccess(dark){
  const st = STATE.formStudent || STUDENTS[0];
  const tokenId = "a7f21ab9c8d4e5f6b3e8991d4a2c7f6b";
  return `
  <div class="screen success ${dark?'dark':''}">
    <div class="notch"></div>
    <div class="status-bar" style="color:#fff"><span>9:41</span><span class="right"><span style="font-size:11px">100%</span></span></div>

    <div class="success-header">
      <div class="check">
        <svg class="i i-lg" viewBox="0 0 24 24" style="stroke:#fff;stroke-width:3"><path d="M20 6L9 17l-5-5"/></svg>
      </div>
      <h2>You're registered.</h2>
      <p>Show this QR at the exam hall entrance. Do not share it.</p>
    </div>

    <div class="qr-wrap">
      <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:14px">
        <span class="chip emerald">${ICO.check.replace('class="i"','class="i i-sm"')} VALID</span>
        <span style="font-size:10px;color:var(--ink-3);letter-spacing:.12em;text-transform:uppercase">One-time use</span>
      </div>
      <div class="qr-code">${fakeQrSvg(42)}</div>
      <div class="qr-meta">SESSION #${SESSION.id} · ${SESSION.semester.split(' ')[0]} ${SESSION.year}</div>
    </div>

    <div class="detail-grid">
      <div><div class="k">Student</div><div class="v">${st.name.split(' ').slice(0,2).join(' ')}</div></div>
      <div><div class="k">Matric No.</div><div class="v mono">${st.matric}</div></div>
      <div><div class="k">Department</div><div class="v" style="font-size:12px">${st.dept}</div></div>
      <div><div class="k">Token ID</div><div class="v mono">${tokenId.slice(0,8)}…${tokenId.slice(-4)}</div></div>
    </div>

    <div class="action-row">
      <button class="btn btn-primary">${ICO.download} Save to Wallet</button>
      <button class="btn btn-ghost" onclick="goto('register'); STATE.formStudent=null; STATE.formMatric=''; STATE.formRRR=''">Register another student</button>
    </div>

    <div class="home"></div>
  </div>`;
}

function screenLogin(dark){
  const s = STATE;
  return `
  <div class="screen ${dark?'dark':''}" style="position:relative">
    <div class="login-bg"><div class="pattern"></div></div>
    <div class="notch"></div>
    <div class="status-bar"><span>9:41</span><span class="right"><span style="font-size:11px">100%</span></span></div>

    <div style="position:absolute;top:56px;left:20px;z-index:10">
      <button class="back" onclick="goto('landing')" style="background:var(--bg-2);border:1px solid var(--line);width:40px;height:40px;border-radius:12px;display:flex;align-items:center;justify-content:center">${ICO.back}</button>
    </div>

    <div class="login-card">
      <span class="badge">Examiner Access</span>
      <h2>Sign in to begin</h2>
      <p class="sub">Verify QR tokens at your assigned exam hall.</p>

      <form onsubmit="submitLogin(event)">
        <div class="field">
          <label>Username</label>
          <input class="input" type="text" placeholder="examiner1" value="${s.loginUser}" oninput="STATE.loginUser=this.value" autocomplete="username"/>
        </div>
        <div class="field">
          <label>Password</label>
          <div style="position:relative">
            <input class="input" type="password" placeholder="••••••••••" value="${s.loginPass}" oninput="STATE.loginPass=this.value" autocomplete="current-password" style="padding-right:48px"/>
            <button type="button" style="position:absolute;right:4px;top:4px;width:42px;height:42px;display:flex;align-items:center;justify-content:center;color:var(--ink-3)">${ICO.eye}</button>
          </div>
        </div>

        ${s.loginError ? `<div class="error-box">${ICO.warn.replace('class="i"','class="i i-sm"')}<div>${s.loginError}</div></div>` : ''}

        <button type="submit" class="btn btn-primary btn-block" style="margin-top:8px" ${s.loginLoading?'disabled':''}>
          ${s.loginLoading
            ? `<span class="spin" style="width:18px;height:18px;border:2px solid rgba(255,255,255,.3);border-top-color:#fff;border-radius:50%;display:inline-block"></span> Signing in…`
            : `${ICO.shield} Sign in to Scanner`}
        </button>

        <div style="display:flex;align-items:center;gap:8px;margin:18px 0 14px">
          <div style="flex:1;height:1px;background:var(--line)"></div>
          <span style="font-size:11px;color:var(--ink-4);letter-spacing:.1em">SECURE ACCESS</span>
          <div style="flex:1;height:1px;background:var(--line)"></div>
        </div>

        <div style="display:flex;gap:8px;padding:10px;background:var(--bg);border-radius:10px;font-size:11px;color:var(--ink-3);line-height:1.5">
          ${ICO.shield.replace('class="i"','class="i i-sm"')}
          <div>Sessions expire after 4 hours of inactivity. All scans are cryptographically logged and tied to your examiner ID.</div>
        </div>
      </form>
    </div>

    <div class="home"></div>
  </div>`;
}

function screenScanner(dark){
  const s = STATE;
  return `
  <div class="screen" style="position:relative">
    <div class="scanner">
      <div class="scanner-viewport">
        <div class="camera-feed">
          <div class="fake-hall"></div>
        </div>
        <div class="reticle">
          <div class="dim-overlay"></div>
          <div class="corners"><span></span><span></span><span></span><span></span></div>
          <div class="scan-line"></div>
        </div>
      </div>

      <div class="scanner-top">
        <div class="ex-info">
          <div class="ex-avatar">EO</div>
          <div><b>Examiner One</b><span>Hall A · Session #${SESSION.id}</span></div>
        </div>
        <button class="iconbtn" onclick="goto('landing')">${ICO.logout}</button>
      </div>

      <div class="scanner-prompt">
        ${s.scanState==='scanning'
          ? `<b>Detecting QR…</b><span class="dots" style="margin-left:4px"><span></span><span></span><span></span></span>`
          : `Point the camera at the student's <b>CERNIX QR</b>`}
      </div>

      <div class="scanner-bottom">
        <div class="scanner-stats">
          <div class="stat-tile"><b>${s.scanCounts.total}</b><span>Scans</span></div>
          <div class="stat-tile approved"><b>${s.scanCounts.approved}</b><span>Approved</span></div>
          <div class="stat-tile rejected"><b>${s.scanCounts.rejected}</b><span>Rejected</span></div>
          <div class="stat-tile duplicate"><b>${s.scanCounts.duplicate}</b><span>Duplicate</span></div>
        </div>

        <div class="last-scan ${s.lastScanStudent?.decision==='APPROVED'?'approved':s.lastScanStudent?.decision==='REJECTED'?'rejected':s.lastScanStudent?.decision==='DUPLICATE'?'duplicate':''}">
          <span class="dot"></span>
          <div class="info">
            <b>${s.lastScanStudent? s.lastScanStudent.name : 'No scans yet'}</b>
            <span>${s.lastScanStudent? s.lastScanStudent.matric+' · '+s.lastScanStudent.decision : 'Awaiting first QR'}</span>
          </div>
          <span class="time">${s.lastScanStudent? s.lastScanStudent.time : '--:--'}</span>
        </div>

        <div class="scan-actions">
          <button onclick="simulateScan('APPROVED')">${ICO.check.replace('class="i"','class="i i-sm"')} Demo Approve</button>
          <button onclick="simulateScan('REJECTED')">${ICO.x.replace('class="i"','class="i i-sm"')} Reject</button>
          <button onclick="simulateScan('DUPLICATE')">${ICO.warn.replace('class="i"','class="i i-sm"')} Duplicate</button>
        </div>
      </div>
    </div>

    ${s.scanState==='approved' ? takeoverApproved() : ''}
    ${s.scanState==='rejected' ? takeoverRejected() : ''}
    ${s.scanState==='duplicate' ? takeoverDuplicate() : ''}
    <div class="home" style="background:#fff"></div>
  </div>`;
}

function takeoverApproved(){
  const st = STATE.lastScanStudent || STUDENTS[0];
  return `
  <div class="takeover approved">
    <div class="top">
      <span class="status-label">DECISION · APPROVED</span>
      <span class="time">${st.time||'09:14:44'}</span>
    </div>
    <div>
      <div class="center" style="margin-top:20px">
        <div class="big-icon">${ICO.check}</div>
        <h1 class="headline">VERIFIED</h1>
        <p class="sub">Access granted. Allow entry.</p>
      </div>

      <div class="student-card">
        <div class="avatar">${st.initials||'AO'}</div>
        <div style="flex:1">
          <p class="nm">${st.name}</p>
          <p class="mt">${st.matric}</p>
          <p class="dept">${st.dept}</p>
        </div>
      </div>

      <div class="meta-row">
        <div class="meta-cell"><div class="k">Token</div><div class="v">${st.token||'a7f2…6b'}</div></div>
        <div class="meta-cell"><div class="k">Session</div><div class="v">#${SESSION.id}</div></div>
      </div>
    </div>

    <div class="bottom">
      <button onclick="resetScan()">Next Scan</button>
      <button class="primary" onclick="resetScan()">${ICO.check.replace('class="i"','class="i i-sm"')} Admit Student</button>
    </div>
  </div>`;
}

function takeoverRejected(){
  return `
  <div class="takeover rejected">
    <div class="top">
      <span class="status-label">DECISION · REJECTED</span>
      <span class="time">${STATE.lastScanStudent?.time||'09:40:18'}</span>
    </div>
    <div>
      <div class="center" style="margin-top:20px">
        <div class="big-icon">${ICO.x}</div>
        <h1 class="headline">REJECTED</h1>
        <p class="sub">Do not admit. Escalate to supervisor.</p>
      </div>

      <div class="reason-list">
        <div class="reason">${ICO.x.replace('class="i"','class="i i-sm"')}<div><b>HMAC signature mismatch</b><br/><span style="opacity:.75;font-size:11px">Token was tampered with or forged</span></div></div>
        <div class="reason">${ICO.warn.replace('class="i"','class="i i-sm"')}<div><b>Session binding invalid</b><br/><span style="opacity:.75;font-size:11px">Token not issued for session #${SESSION.id}</span></div></div>
      </div>

      <div class="meta-row">
        <div class="meta-cell"><div class="k">Scan #</div><div class="v">${STATE.scanCounts.total}</div></div>
        <div class="meta-cell"><div class="k">Logged</div><div class="v">YES</div></div>
      </div>
    </div>

    <div class="bottom">
      <button onclick="resetScan()">Dismiss</button>
      <button class="primary" onclick="resetScan()">${ICO.flash.replace('class="i"','class="i i-sm"')} Alert Supervisor</button>
    </div>
  </div>`;
}

function takeoverDuplicate(){
  const st = STATE.lastScanStudent || STUDENTS[0];
  return `
  <div class="takeover duplicate">
    <div class="top">
      <span class="status-label">DECISION · ALREADY USED</span>
      <span class="time">${st.time||'09:31:12'}</span>
    </div>
    <div>
      <div class="center" style="margin-top:20px">
        <div class="big-icon">${ICO.warn}</div>
        <h1 class="headline">ALREADY<br/>USED</h1>
        <p class="sub">Token was redeemed earlier today. Entry denied.</p>
      </div>

      <div class="student-card">
        <div class="avatar">${st.initials}</div>
        <div style="flex:1">
          <p class="nm">${st.name}</p>
          <p class="mt">${st.matric}</p>
          <p class="dept" style="color:rgba(255,255,255,.9);margin-top:6px">First redeemed: <b>08:54:21</b></p>
        </div>
      </div>

      <div class="meta-row">
        <div class="meta-cell"><div class="k">Original Hall</div><div class="v">Hall B</div></div>
        <div class="meta-cell"><div class="k">Original Examiner</div><div class="v">examiner3</div></div>
      </div>
    </div>

    <div class="bottom">
      <button onclick="resetScan()">Dismiss</button>
      <button class="primary" onclick="resetScan()">${ICO.history.replace('class="i"','class="i i-sm"')} View Audit Trail</button>
    </div>
  </div>`;
}

// ============================================================
// ADMIN (desktop preferred but mobile-responsive)
// ============================================================
function adminContent(dark){
  return `
  <div class="admin">
    <div class="admin-head">
      <div>
        <h1>Admin Dashboard</h1>
        <p class="sub">Read-only view of verification activity and audit log</p>
      </div>
      <button class="btn btn-ghost" style="min-height:auto;padding:10px 16px;font-size:13px">${ICO.refresh.replace('class="i"','class="i i-sm"')} Refresh Logs</button>
    </div>

    <div class="session-hero">
      <div>
        <div class="eyebrow">Active Exam Session</div>
        <div class="title">${SESSION.semester} · ${SESSION.year}</div>
        <div class="meta">
          <span>Session #${SESSION.id}</span>
          <span>Fee: ₦${SESSION.fee.toLocaleString()}</span>
          <span>Started: 2026-04-16</span>
        </div>
      </div>
      <span class="live-badge"><span class="pulse-dot"></span>LIVE</span>
    </div>

    <div class="stat-grid">
      <div class="stat-card">
        <div class="label">${ICO.scan.replace('class="i"','class="i i-sm"')} Total Scans</div>
        <div class="value">${STATS.total}</div>
        <div class="trend">All-time</div>
      </div>
      <div class="stat-card ok">
        <div class="label">${ICO.check.replace('class="i"','class="i i-sm"')} Approved</div>
        <div class="value">${STATS.approved}</div>
        <div class="trend">${Math.round(STATS.approved/STATS.total*100)}% of total</div>
      </div>
      <div class="stat-card bad">
        <div class="label">${ICO.x.replace('class="i"','class="i i-sm"')} Rejected</div>
        <div class="value">${STATS.rejected}</div>
        <div class="trend">${Math.round(STATS.rejected/STATS.total*100)}% of total</div>
      </div>
      <div class="stat-card warn">
        <div class="label">${ICO.warn.replace('class="i"','class="i i-sm"')} Duplicates</div>
        <div class="value">${STATS.duplicate}</div>
        <div class="trend">${Math.round(STATS.duplicate/STATS.total*100)}% of total</div>
      </div>
    </div>

    <div class="tabs">
      <button class="on">Verification Logs</button>
      <button>Audit Log</button>
      <button>Sessions</button>
      <button>Examiners</button>
    </div>

    <div class="panel">
      <div class="panel-head"><h3>Verification Logs</h3><span class="count">${LOGS.length} records · newest first</span></div>
      ${LOGS.map((l,i)=>`
        <div class="log-row">
          <div class="n">#${String(i+1).padStart(3,'0')}</div>
          <div class="body">
            <b>${l.ex}</b>
            <div class="sub">${l.token}</div>
          </div>
          <div class="right">
            <span class="chip ${l.decision==='APPROVED'?'emerald':l.decision==='REJECTED'?'red':'amber'}">${l.decision}</span>
            <span class="t">${l.t} · ${l.ip}</span>
          </div>
        </div>
      `).join('')}
    </div>

    <div class="panel">
      <div class="panel-head"><h3>Audit Log</h3><span class="count">${AUDIT.length} entries</span></div>
      ${AUDIT.map((a,i)=>`
        <div class="log-row">
          <div class="n">#${String(i+1).padStart(3,'0')}</div>
          <div class="body">
            <b>${a.actor} <span class="chip ${a.type==='admin'?'navy':a.type==='examiner'?'blue':'emerald'}" style="margin-left:6px">${a.type}</span></b>
            <div class="sub">${a.action} · ${a.meta}</div>
          </div>
          <div class="right"><span class="t">${a.t}</span></div>
        </div>
      `).join('')}
    </div>

    <div class="panel">
      <div class="panel-head"><h3>Exam Sessions</h3><button class="btn btn-ghost" style="min-height:auto;padding:6px 12px;font-size:12px">${ICO.plus.replace('class="i"','class="i i-sm"')} New Session</button></div>
      <div class="session-card">
        <div class="s-ico">${ICO.calendar}</div>
        <div class="s-body"><b>First Semester · 2025/2026</b><span>Fee ₦10,000 · Started 2026-04-16</span></div>
        <div class="toggle on"></div>
      </div>
      <div class="session-card">
        <div class="s-ico" style="color:var(--ink-4)">${ICO.calendar}</div>
        <div class="s-body"><b style="color:var(--ink-3)">Second Semester · 2024/2025</b><span>Fee ₦10,000 · Ended 2025-12-12</span></div>
        <div class="toggle"></div>
      </div>
    </div>

    <div class="panel">
      <div class="panel-head"><h3>Examiners</h3><button class="btn btn-ghost" style="min-height:auto;padding:6px 12px;font-size:12px">${ICO.plus.replace('class="i"','class="i i-sm"')} Add Examiner</button></div>
      ${EXAMINERS.map(e=>`
        <div class="examiner-row">
          <div class="av">${e.initials}</div>
          <div class="bd"><b>${e.name}</b><span>@${e.username}</span></div>
          <span class="chip ${e.role==='admin'?'navy':'blue'}">${e.role.toUpperCase()}</span>
          <span class="chip ${e.active?'emerald':'red'}">${e.active?'ACTIVE':'INACTIVE'}</span>
        </div>
      `).join('')}
    </div>
  </div>`;
}

function screenAdminMobile(dark){
  return `
  <div class="screen ${dark?'dark':''}">
    <div class="notch"></div>
    <div class="status-bar"><span>9:41</span><span class="right"><span style="font-size:11px">100%</span></span></div>
    <div class="topbar border">
      <button class="back" onclick="goto('landing')">${ICO.back}</button>
      <h1>Admin</h1>
    </div>
    ${adminContent(dark)}
    <div class="home"></div>
  </div>`;
}

function screenAdminDesktop(dark){
  return `
  <div class="${dark?'dark':''}" style="min-height:100%;background:var(--bg);color:var(--ink)">
    <div class="admin-desktop">
      <aside class="admin-sidebar">
        <div class="brand">
          <div class="logo-mark"><span class="logo-glyph"></span><span>CERNIX</span></div>
        </div>
        <div class="nav-item on">${ICO.admin.replace('class="i"','class="i i-sm"')}<span>Dashboard</span></div>
        <div class="nav-item">${ICO.history.replace('class="i"','class="i i-sm"')}<span>Verification Logs</span></div>
        <div class="nav-item">${ICO.shield.replace('class="i"','class="i i-sm"')}<span>Audit Trail</span></div>
        <div class="nav-item">${ICO.calendar.replace('class="i"','class="i i-sm"')}<span>Exam Sessions</span></div>
        <div class="nav-item">${ICO.user.replace('class="i"','class="i i-sm"')}<span>Examiners</span></div>
        <div class="nav-item">${ICO.student.replace('class="i"','class="i i-sm"')}<span>Students (SIS)</span></div>
        <div style="margin-top:20px;padding-top:14px;border-top:1px solid var(--line)">
          <div class="nav-item">${ICO.settings.replace('class="i"','class="i i-sm"')}<span>Settings</span></div>
          <div class="nav-item">${ICO.logout.replace('class="i"','class="i i-sm"')}<span>Sign out</span></div>
        </div>
        <div style="margin-top:24px;padding:12px;background:var(--bg);border-radius:10px;font-size:11px;color:var(--ink-3);line-height:1.5">
          Signed in as <b style="color:var(--ink);display:block;margin-top:4px">admin1</b>
        </div>
      </aside>
      <main class="admin-main">
        ${adminContent(dark)}
      </main>
    </div>
  </div>`;
}
