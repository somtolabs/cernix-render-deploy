# CERNIX — Exam Hall Verification Prototype

A single-file HTML prototype of the CERNIX exam hall verification system, covering every screen in the Laravel codebase (`bright1122-os/cernix-exam-verify`).

## Files

- **`cernix-prototype.html`** — the original prototype. Self-contained (all CSS + JS inlined). Ships with dark + light variants side by side.
- **`cernix-anthropic.html`** — an alternate take in the Anthropic design language: warm cream on near-black, terracotta accent, Fraunces serif, real photography. Also self-contained, also dark + light.

Both files are standalone — just open in any modern browser. No build step.

## What's in each

Both prototypes cover the full flow:

1. **Landing** — role picker (Student · Examiner)
2. **Student registration** — matric + Remita RRR
3. **QR success** — generated token, student details
4. **Examiner login** — staff credentials
5. **Scanner** — camera view with reticle
6. **Verification result** — Approved / Rejected / Duplicate states
7. **Admin dashboard** — stats, verification log, audit trail

## Themes

Each prototype renders **dark** (primary) and **light** (secondary) variants in the same page, so you can see both at once.

- In `cernix-prototype.html`, the variants sit side-by-side in the gallery.
- In `cernix-anthropic.html`, the theme toggle is exposed in the Tweaks panel (`Dark` / `Light` / `Both`).

## Tweaks

`cernix-anthropic.html` includes an in-design Tweaks panel (toggled from the toolbar) for:
- Theme (Dark / Light / Both)
- Accent colour (Terracotta / Navy)
- Result preview (Verified / Rejected / Used)

## Source

Structure, routes, and data fields are faithful to the Laravel views at:
- `cernix/resources/views/welcome.blade.php`
- `cernix/resources/views/student/register.blade.php`
- `cernix/resources/views/examiner/dashboard.blade.php`
- `cernix/resources/views/admin/dashboard.blade.php`

## License

Prototype — for design review only.
